
COLORS = {
    'red':    '\033[91m',
    'blue':   '\033[94m',
    'green':  '\033[32m',
    'black':  '\033[30m',
    'yellow': '\033[33m',
    'bold':   '\033[1m',
}

CLEAR = '\033[0m'
