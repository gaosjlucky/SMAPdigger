./dmr /nas/RD_12A/gaoshengjie/software/SMAP/sRRBS_40-220_region.bed /nas/RD_12A/gaoshengjie/software/SMAP/SMAP_new_installed/outtest/K1/Normal/ASM/meth.cg  /nas/RD_12A/gaoshengjie/software/SMAP/SMAP_new_installed/outtest/K1/MB/ASM/meth.cg /nas/RD_12A/gaoshengjie/software/SMAP/SMAP_new_installed/outtest/K1/MB/DMR/dmr.out

