/*************************
Author:			gaocd
Version:		1.0
Last modify:	2015/12/03
*************************/

//dmr���ܿس���
//
#include <stdio.h>
#include <unistd.h> 
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "dmr_const.h"
int CheckPara(int argc, char *argv[]);
int CheckFile();
int DivideRange(char *RangeFileName);
int UnionFile(char *FirstFileName, char *SecondFileName,char *UnionFileName);
int CoreSearch(char *UnionFileName,char *DmrFileName);
void DeleteTempFile();

const char *USAGE="<RangeFile> <FirstFile> <SecondFile> <DmrFile> [/d=<v1>] [/t=<v2>] [/k=<v3>] [/c=<v4>] [/s=<v5>] [/m|/M] [/r|/R]\n";
char RangeFileName[FILE_NAME_MAX],FirstFileName[FILE_NAME_MAX],SecondFileName[FILE_NAME_MAX],UnionFileName[FILE_NAME_MAX],DmrFileName[FILE_NAME_MAX];
char WorkDir[FILE_NAME_MAX];
double RATIO_DEF_MIN=0.1,PVALUE_T_MAX=0.05,PVALUE_CHII_MAX=0.01;
int CORE_LEN_MIN=5,CORE_EXP_SKIP_MAX=280,ShowProgress=1;
int RemainUnionFile=1;

int main(int argc, char* argv[])
{
	if (!CheckPara(argc, argv))	exit(1);
	if (!CheckFile())exit(1);
	if (!DivideRange(RangeFileName)){DeleteTempFile(); exit(2);}
	if (!UnionFile(FirstFileName, SecondFileName, UnionFileName)){DeleteTempFile();	exit(3);}
	if (!CoreSearch(UnionFileName,DmrFileName)){DeleteTempFile(); exit(4);}
	DeleteTempFile();
	return 0;
}

int CheckPara(int argc, char *argv[])
{
	int i,OK=1;
	char tag;
	if((argc<5) || (argc>12))	OK=0;
	else
	{
		strcpy(RangeFileName,argv[1]);
		strcpy(FirstFileName,argv[2]);
		strcpy(SecondFileName,argv[3]);
		strcpy(DmrFileName,argv[4]);
		strcpy(UnionFileName,DmrFileName);
		strcat(UnionFileName,".union");

		for(i=5; i<argc; i++)
		{	if(argv[i][0]!='/'){OK=0;break;}
			tag=tolower(argv[i][1]);
			switch(tag)
			{	case 'd':
					if(argv[i][2]!='=')OK=0;
					else sscanf(argv[i]+3,"%lf",&RATIO_DEF_MIN);
					break;
				case 't':
					if(argv[i][2]!='=')OK=0;
					else sscanf(argv[i]+3,"%lf",&PVALUE_T_MAX);
					break;
				case 'k':
					if(argv[i][2]!='=')OK=0;
					else sscanf(argv[i]+3,"%lf",&PVALUE_CHII_MAX);
					break;
				case 'c':
					if(argv[i][2]!='=')OK=0;
					else sscanf(argv[i]+3,"%d",&CORE_LEN_MIN);
					break;
				case 's':
					if(argv[i][2]!='=')OK=0;
					else sscanf(argv[i]+3,"%d",&CORE_EXP_SKIP_MAX);
					break;
				case 'm':
					ShowProgress=0;
					break;
				case 'r':
					RemainUnionFile=0;
					break;
				default:
					OK=0;
			}
			if(!OK)break;
		}
	}
	if(!OK)	printf(USAGE);
	return OK;
}

int CheckFile()
{
	int i,n;
	if(access(RangeFileName,0)) return 0;//�ļ�������
	if(access(FirstFileName,0)) return 0;//�ļ�������
	if(access(SecondFileName,0)) return 0;//�ļ�������
	strcpy(WorkDir,DmrFileName);
	for(i=strlen(WorkDir)-1;i>0;i--)
		if(('/'==WorkDir[i]) || ('\\'==WorkDir[i])) break;
	if(0==i)WorkDir[0]=0;
	else WorkDir[i+1]=0;
	return 1;
}

void DeleteTempFile()
{
	int i;
	char FullFileName[FILE_NAME_MAX];
	char ChrName[CHR_NAME_MAX];
	for(i=1;i<=23;i++)
	{
		sprintf(ChrName,"chr%d",i);
		strcpy(FullFileName,WorkDir);
		strcat(FullFileName,ChrName);
		remove(FullFileName);
	}
	strcpy(FullFileName,WorkDir);
	strcat(FullFileName,"chrM");
	remove(FullFileName);
	strcpy(FullFileName,WorkDir);
	strcat(FullFileName,"chrX");
	remove(FullFileName);
	strcpy(FullFileName,WorkDir);
	strcat(FullFileName,"chrY");
	remove(FullFileName);
	if(!RemainUnionFile) remove(UnionFileName);
}
