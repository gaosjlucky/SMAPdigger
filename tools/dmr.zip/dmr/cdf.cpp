//---------��������t_pvalue��chi2_pvalue���ӳ���--------------------
#include <math.h>

double tcdf(double x,int n)
{
	const double PI=3.1415926536;
	double a,b,w,y,z,r;
	int i;

	w=atan2(x/sqrt(n),1);
	z=cos(w);z=z*z;
	y=1.0;
	for(i=n-2;i>=2; i-=2)
	{
		y=1+y*z*(i-1)/i;
	}
	if(0==n%2)
	{	a=sin(w)/2;
		b=0.5;
	}
	else
	{	a=(1==n)?0:sin(w)*cos(w)/PI;
		b=0.5+w/PI;
	}
	r=1-b-a*y;
	return r>0?r:0;
}

double Chi2Deta(double x1,double x2)
{
	const double ROOT_PI=1.77245385;//�̦�
	const int N=100000;
	double ReturnValue=0,xx1,xx2,y1,y2,Deta,t;
	int i;
	if(x1>x2){t=x1;x1=x2;x2=t;}
	Deta=(x2-x1)/N;
	xx1=x1; y1=exp(-xx1)/sqrt(xx1);
	for(i=0;i<N;i++)
	{	xx2=xx1+Deta; 
		y2=exp(-xx2)/sqrt(xx2);
		ReturnValue += (y1+y2)*Deta/2;
		xx1=xx2;y1=y2;
	}
	return ReturnValue/ROOT_PI;
}

double chi2cdf(double x1,double x2)
{
	return Chi2Deta(x1/2.0,x2/2.0);
}
