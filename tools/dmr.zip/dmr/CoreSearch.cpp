
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "dmr_const.h"

double tcdf(double x,int n);
double chi2cdf(double x1,double x2);

extern int ShowProgress;
extern char DmrFileName[FILE_NAME_MAX];
extern double RATIO_DEF_MIN,PVALUE_T_MAX,PVALUE_CHII_MAX;
extern int CORE_LEN_MIN,CORE_EXP_SKIP_MAX,ShowProgress;


const int BUFFER_MAX=4096;//������4096��
const int CORE_LEN_MAX=2048; 
const char *DmrFileHeader="#chr\tpos_start\tpos_end\tshared_num/methy_in_normal/methy_in_tumor/pos_num\ttumor_methy_num/tumor_NONE_methy_num\ttumor_methy_ratio\tnormal_methy_num/normal_NONE_methy_num\tnormal_methy_ratio\tchisq.test_p-value\tt.test_p-value\n";

static FILE *fpUnion=NULL,*fpDmr=NULL;		//�����ļ�������ļ����

static int buffer[BUFFER_MAX][9];  //��������ÿ��ֻ��9������
static double a1[CORE_LEN_MAX],a2[CORE_LEN_MAX]; //�����׻�������
static int CoreBufStart,CoreLength;//Core��ӦBuffer�±꣬Core��ʼ����ǰPOSֵλ�ã�Core����
static char ChrTreat[CHR_NAME_MAX]="";//��ǰchr
static double CoreSignDr;//Core��ǰ�׻����ʲ�ķ���
static double CoreTpvalue;//Core��ǰTpvalueֵ
static double CoreChiipvalue;//Core��ǰChiipvalueֵ
static int n1,n2,sum1,Sum1,sum2,Sum2;//Coreͳ����

int csOpenFile(char *UnionFileName,char *DmrFileName);//�������ļ�
void csCloseFile();//�ر����򿪵��ļ�
void csProcess();

int csGetValue(int Index,char *ChrRead); //����һ��
void csStartCore(int Index, int Length);//��ʼһ��core
void csOutputCore(int Count);//���һ��Core
void csGetCoreM(int Length,int *CoreM1,int *CoreM2,int *CoreM3,int *CoreM4);

int csCoreCheck();//���Core�Ƿ���������
int csCoreExpCheck();//���Core��չ�Ƿ�ɹ�

void csGetData();
void csAppendData(int *s1,int *S1,int *s2,int *S2);
double csGetTpvalue();
double csGetChiipvalue();

int sign(double n);

int CoreSearch(char *UnionFileName,char *DmrFileName)
{
	if(!csOpenFile(UnionFileName,DmrFileName)) return 0;
	csProcess();
	csCloseFile();
	return 1;
}

int csOpenFile(char *UnionFileName,char *DmrFileName)
{
	if(NULL==(fpUnion=fopen(UnionFileName,"r")))
	{
		printf("Error open File %s\n",UnionFileName);
		return 0;
	}
	if(NULL==(fpDmr=fopen(DmrFileName,"w")))
	{
		printf("Error open File %s\n",DmrFileName);
		fclose(fpUnion);
		return 0;
	}
	return 1;
}

void csCloseFile()
{
	if(fpUnion!=NULL) fclose(fpUnion);
	if(fpDmr!=NULL)fclose(fpDmr);
}

void csProcess()
{
	char ChrRead[8];//���ڶ����chr
	int BufIndex;	//�������±�

	if(ShowProgress) printf("Core search start\n");

	fprintf(fpDmr,DmrFileHeader);
	for(BufIndex=0,CoreLength=1; csGetValue(BufIndex,ChrRead); BufIndex=(BufIndex+1)%BUFFER_MAX)
	{	if(strcmp(ChrTreat,ChrRead)==0)
		{
			if(buffer[BufIndex][0]-buffer[(BufIndex-1+BUFFER_MAX)%BUFFER_MAX][0]<=CORE_EXP_SKIP_MAX)
			{
				CoreLength++;
				if(CORE_LEN_MIN==CoreLength)
				{
					if(!csCoreCheck())
					{
						csStartCore((CoreBufStart+1)%BUFFER_MAX,CoreLength-1);
					}
				}
				else if(CoreLength>CORE_LEN_MIN) 
				{	if(!csCoreExpCheck())
					{	csOutputCore(CoreLength-1);
						csStartCore(BufIndex,1);
					}
					else if(CoreLength==CORE_LEN_MAX)
					{	csOutputCore(CoreLength);
						csStartCore(BufIndex,1);
					}
				}
			}
			else
			{
				if(CoreLength>=CORE_LEN_MIN) csOutputCore(CoreLength);
				csStartCore(BufIndex,1);
			}
		}
		else
		{
			if(ShowProgress) if(strcmp(ChrTreat,"")!=0)printf("Ok\n");
			if(CoreLength>=CORE_LEN_MIN) csOutputCore(CoreLength);
			csStartCore(BufIndex,1);
			strcpy(ChrTreat,ChrRead);
			if(ShowProgress) printf("\tProcessing %s ... ",ChrTreat);
		}
	}
	if(CoreLength>=CORE_LEN_MIN) csOutputCore(CoreLength);
	if(ShowProgress) printf("OK\nCore search finished!\n");
}

int csGetValue(int Index,char *s)
{
//chr18	42076257	CG	5	10	37	4	10	37	5	10	37	4	10	37
	char Line[LINE_MAX],t[CHR_NAME_MAX];
	int i,j;
	if(fgets(Line,LINE_MAX,fpUnion)==NULL) return 0;

	for(i=0,j=0; (s[j]=Line[i])!='\t'; i++,j++);
	s[j]=0;//s=="chr18"
	for(i++,j=0; (t[j]=Line[i])!='\t'; i++,j++);
	t[j]=0;//t=="42076257"
	sscanf(t,"%d",&(buffer[Index][0]));
	for(i++,j=0; (t[j]=Line[i])!='\t'; i++,j++); //����
	t[j]=0;//t=="CG"
	for(i++,j=0; (t[j]=Line[i])!='\t'; i++,j++); 
	t[j]=0;//t=="5"
	if('.'==t[0]) buffer[Index][1]=-1;
	else sscanf(t,"%d",&(buffer[Index][1]));
	for(i++,j=0; (t[j]=Line[i])!='\t'; i++,j++); 
	t[j]=0;//t=="10"
	if('.'==t[0]) buffer[Index][2]=-1;
	else sscanf(t,"%d",&(buffer[Index][2]));
	for(i++,j=0; (t[j]=Line[i])!='\t'; i++,j++); //����
	t[j]=0;//t=="37"
	for(i++,j=0; (t[j]=Line[i])!='\t'; i++,j++); 
	t[j]=0;//t=="4"
	if('.'==t[0]) buffer[Index][3]=-1;
	else sscanf(t,"%d",&(buffer[Index][3]));
	for(i++,j=0; (t[j]=Line[i])!='\t'; i++,j++); 
	t[j]=0;//t=="10"
	if('.'==t[0]) buffer[Index][4]=-1;
	else sscanf(t,"%d",&(buffer[Index][4]));
	for(i++,j=0; (t[j]=Line[i])!='\t'; i++,j++); //����
	t[j]=0;//t=="37"
	for(i++,j=0; (t[j]=Line[i])!='\t'; i++,j++); 
	t[j]=0;//t=="5"
	if('.'==t[0]) buffer[Index][5]=-1;
	else sscanf(t,"%d",&(buffer[Index][5]));
	for(i++,j=0; (t[j]=Line[i])!='\t'; i++,j++); 
	t[j]=0;//t=="10"
	if('.'==t[0]) buffer[Index][6]=-1;
	else sscanf(t,"%d",&(buffer[Index][6]));
	for(i++,j=0; (t[j]=Line[i])!='\t'; i++,j++); //����
	t[j]=0;//t=="37"
	for(i++,j=0; (t[j]=Line[i])!='\t'; i++,j++); 
	t[j]=0;//t=="4"
	if('.'==t[0]) buffer[Index][7]=-1;
	else sscanf(t,"%d",&(buffer[Index][7]));
	for(i++,j=0; (t[j]=Line[i])!='\t'; i++,j++); 
	t[j]=0;//t=="10"
	if('.'==t[0]) buffer[Index][8]=-1;
	else sscanf(t,"%d",&(buffer[Index][8]));
	return 1;
}

void csStartCore(int Index,int Length)
{
	CoreBufStart=Index; 
	CoreLength=Length;
}

void csOutputCore(int Length)
{
	int CorePosStart,CorePosEnd,CoreM1,CoreM2,CoreM3,CoreM4;

	CorePosStart=buffer[CoreBufStart][0];
	CorePosEnd=buffer[(CoreBufStart+Length-1)%BUFFER_MAX][0];
	csGetCoreM(Length,&CoreM1,&CoreM2,&CoreM3,&CoreM4);

	fprintf(fpDmr,"%s\t",ChrTreat);
	fprintf(fpDmr,"%d\t%d\t",CorePosStart,CorePosEnd);
	fprintf(fpDmr,"%d/%d/%d/%d\t",CoreM1,CoreM2,CoreM3,CoreM4);
	fprintf(fpDmr,"%d/%d\t%4.2f\t",sum1,Sum1-sum1,(float)sum1/Sum1);
	fprintf(fpDmr,"%d/%d\t%4.2f\t",sum2,Sum2-sum2,(float)sum2/Sum2);
	fprintf(fpDmr,"%.2e\t%.2e\n",CoreChiipvalue,CoreTpvalue);
 }

void csGetCoreM(int Length,int *CoreM1,int *CoreM2,int *CoreM3,int *CoreM4)
{
	int i,ii,m1,m2,m3,t1,t2;

	m1=m2=m3=0;
	for(i=0; i<Length; i++)
	{	ii=(CoreBufStart+i)%BUFFER_MAX;
		t1=((buffer[ii][1]!=-1)||(buffer[ii][3]!=-1))?1:0;
		t2=((buffer[ii][5]!=-1)||(buffer[ii][7]!=-1))?1:0;
		m1+=t1*t2;	m2+=t1;	m3+=t2;
	}
	*CoreM1=m1;*CoreM2=m2;*CoreM3=m3;*CoreM4=Length;
}
//------------
int csCoreCheck()
{
	double r1,r2;
//Ϊ����3������׼������
	csGetData();
//�׻����ʲ����
	if( (0==Sum1) || (0==Sum2) ) return 0;//�޷���׻����ʵ����
	r1=(double)sum1/Sum1;
	r2=(double)sum2/Sum2;
	if(fabs(r1-r2)<=RATIO_DEF_MIN) return 0;//�׻����ʲ�����
	CoreSignDr=sign(r1-r2);//����׻����ʲ�ķ��ţ���Core��չ����
//t����
	CoreTpvalue=csGetTpvalue();
	if(CoreTpvalue>=PVALUE_T_MAX) return 0; //t��������
//Chii����
	CoreChiipvalue=csGetChiipvalue();//��sum1,Sum1,sum2,Sum2������
	if(CoreChiipvalue>=PVALUE_CHII_MAX) return 0;//Chii��������
	return 1;
}

void csGetData()
{	int i,ii,t1,T1,t2,T2;
	
	n1=n2=sum1=Sum1=sum2=Sum2=0;
	for(i=0; i<CoreLength; i++)
	{	ii=(CoreBufStart+i)%BUFFER_MAX;
		t1=T1=t2=T2=0;
		if(buffer[ii][1]!=-1)
		{	t1+=buffer[ii][1];
			T1+=buffer[ii][2];
		}
		if(buffer[ii][3]!=-1)
		{	t1+=buffer[ii][3];
			T1+=buffer[ii][4];
		}
		if(T1!=0)
		{	a1[n1]=(double)t1/T1; n1++;	
		}
		sum1+=t1;	Sum1+=T1;

		if(buffer[ii][5]!=-1)
		{	t2+=buffer[ii][5];
			T2+=buffer[ii][6];
		}
		if(buffer[ii][7]!=-1)
		{	t2+=buffer[ii][7];
			T2+=buffer[ii][8];
		}
		if(T2!=0)
		{	a2[n2]=(double)t2/T2; n2++;	
		}
		sum2+=t2;	Sum2+=T2;
	}
}

double csGetTpvalue()
{
	int i;
	double x1,x2,s1,s2;
	double tvalue;

	for(x1=0.0,i=0; i<n1; i++) x1+=a1[i];
	x1 /= n1;
	for(x2=0.0,i=0; i<n2; i++) x2+=a2[i];
	x2 /= n2;
	for(s1=0.0,i=0; i<n1; i++) s1+=(a1[i]-x1)*(a1[i]-x1);
	for(s2=0.0,i=0; i<n2; i++) s2+=(a2[i]-x2)*(a2[i]-x2);
	tvalue=fabs(x1-x2)*sqrt( double(n1+n2-2)*n1*n2/(s1+s2)/(n1+n2) );
	return tcdf(tvalue,n1+n2-2);
}

double csGetChiipvalue()
{
	int a, b, c, d;
	double chii_value;

	a=sum1;b=Sum1-sum1;c=sum2;d=Sum2-sum2;
	chii_value=(double)(Sum1+Sum2)*(a*d-b*c)*(a*d-b*c)/(a+b)/(c+d)/(a+c)/(b+d);
	return chi2cdf(chii_value,(double)(Sum1+Sum2));
}

int csCoreExpCheck()
{
	double SignDr,t_value,t_pvalue;
	int s1,S1,s2,S2;
//Ϊ����2������׼������
	csAppendData(&s1,&S1,&s2,&S2);
//�׻����ʷ������
	SignDr=sign((double)s1/S1-(double)s2/S2);
	if(SignDr!=CoreSignDr) return 0;//Core��չ�׻����ʷ�������
//tpvalue�仯����
	t_pvalue=csGetTpvalue();
	if(t_pvalue>CoreTpvalue) return 0; //Core��չt��������
//����ͳ������
	sum1=s1;Sum1=S1;sum2=s2;Sum2=S2;
	CoreTpvalue=t_pvalue;
	CoreChiipvalue=csGetChiipvalue(); ////��sum1,Sum1,sum2,Sum2������
	return 1;
}

void csAppendData(int *s1,int *S1,int *s2,int *S2)
{
	int ii,t1,T1,t2,T2;
	
	t1=T1=t2=T2=0;
	ii=(CoreBufStart+CoreLength-1)%BUFFER_MAX;
	if(buffer[ii][1]!=-1)
	{	t1+=buffer[ii][1];
		T1+=buffer[ii][2];
	}
	if(buffer[ii][3]!=-1)
	{	t1+=buffer[ii][3];
		T1+=buffer[ii][4];
	}
	if(T1!=0) a1[n1++]=(double)t1/T1;
	*s1=sum1+t1; *S1=Sum1+T1;

	if(buffer[ii][5]!=-1)
	{	t2+=buffer[ii][5];
		T2+=buffer[ii][6];
	}
	if(buffer[ii][7]!=-1)
	{	t2+=buffer[ii][7];
		T2+=buffer[ii][8];
	}
	if(T2!=0) a2[n2++]=(double)t2/T2;
	*s2=sum2+t2; *S2=Sum2+T2;
}

int sign(double x)
{
	if (x>0) return 1;
	else if (x==0) return 0;
		 else return -1;
}
