//�ָ�range�ļ����ֳ���Ⱦɫ��Ϊ���Ķ������ļ���
#include <stdio.h>
#include <string.h>

#include "dmr_const.h"

extern int ShowProgress;
extern char WorkDir[FILE_NAME_MAX];

int drProcess(FILE *fpRange);

int DivideRange(char *RangeFileName)
{
	int OK=0;	
	FILE *fpRange;

	fpRange=fopen(RangeFileName,"r");
	if( NULL==fpRange ) printf("Error when open region file <%s>\n",RangeFileName);
	else
	{	OK=drProcess(fpRange);
		fclose(fpRange);
	}
	return OK;
}

int drProcess(FILE *fpRange)
{
	FILE *fpChrFile=NULL;
	const int BLOCK_SUM=1;
	char OneLine[LINE_MAX];
	char ChrName[CHR_NAME_MAX]={0};
	char FullFileName[FILE_NAME_MAX];
	int OK=1,i,start,stop;

	if(ShowProgress) printf("Divide range start\n");
	while(NULL != fgets(OneLine,LINE_MAX,fpRange))
	{
		for(i=0; i<LINE_MAX; i++) 
		{	if('\t'==OneLine[i])
			{	OneLine[i]=0;
				break;
			}
		}
		if(strcmp(ChrName,OneLine)!=0)
		{
			if(fpChrFile!=NULL)
			{	if(ShowProgress) printf("OK\n");
				fclose(fpChrFile);
			}
			strcpy(ChrName,OneLine);
			if(ShowProgress) printf("\tProcessing %s ... ",ChrName);
			strcpy(FullFileName,WorkDir);
			strcat(FullFileName,ChrName);
			if(NULL==(fpChrFile=fopen(FullFileName,"wb")) )
			{	printf("\n\t\tError when create file <%s>\n",ChrName);
				OK=0;
				break;
			}
		}
		if(sscanf(OneLine+i+1,"%d%d",&start,&stop)!=2)
		{	printf("\n\t\tRange file format not correct!\n");
			fclose(fpChrFile);
			OK=0;
			break;
		}
		if(fwrite(&start, sizeof(int), BLOCK_SUM, fpChrFile) != BLOCK_SUM)
		{	printf("\n\t\tError when write to file <%s>\n",ChrName);
			fclose(fpChrFile);
			OK=0;
			break;
		}
		if(fwrite(&stop, sizeof(int), BLOCK_SUM, fpChrFile) != BLOCK_SUM)
		{	printf("\n\t\tError when write to file <%s>\n",ChrName);
			fclose(fpChrFile);
			OK=0;
			break;
		}
	}
	if(!OK) printf("Divide range NOT finished!\n");
	else if(ShowProgress) printf("OK\nDivide range finished!\n");
	if(fpChrFile!=NULL)	fclose(fpChrFile);

	return OK;
}
